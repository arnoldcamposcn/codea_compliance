
  # Landing Page for CODEa Compliance

  This is a code bundle for Landing Page for CODEa Compliance. The original project is available at https://www.figma.com/design/Xdh9YofuWnTWLsrMZpvEjp/Landing-Page-for-CODEa-Compliance.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  